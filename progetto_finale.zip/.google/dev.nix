{ pkgs, ... }: {
      channel = "stable-23.11";
        packages = [
            pkgs.gradle
            pkgs.android-sdk
            pkgs.jdk17
                  ];
                    idx = {
                        extensions = [
                              "vscjava.vscode-java-pack"
                                  ];
                                      previews = {
                                            enable = true;
                                                  previews = {
                                                          web = {
                                                                    command = [ "./gradlew" "assembleDebug" ];
                                                                              manager = "web";
                                                                                      };
                                                                                            };
                                                                                                };
                                                                                                  };
                                                                                                  }
                                                                                                  
}